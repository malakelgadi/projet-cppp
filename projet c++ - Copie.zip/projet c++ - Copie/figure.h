#ifndef FIGURE_H
#define FIGURE_H
#include <graphics.h>
#include "fenetres.h"
#include <iostream>
using namespace std;


class figure
{
	public:
		int a,b,c,x,y,type;
		
		figure(){
	
		 }
		void set_droite(int x, int y,int a,int b,int c){
			if(a>0 && b==0){
				this->c=c;
	            this->x=x;
	            this->y=y;
				this->type=1;
				this->a=a;
				this->b=b;		
			} 
			else if(b>0 && a==0){
				this->c=c;
	            this->x=x;
	            this->y=y;
				this->type=2;
				this->a=a;
				this->b=b;	
			}
			else if(a>0 && b!=0) {
				this->c=c;
	            this->x=x;
	            this->y=y;
				this->type=3;
				this->a=a;
				this->b=b;	
			}
			else  this->type=0;//ou -1;
		}
		
		void set_cercle(int x, int y,int d,int c){
			if(d>0){
				this->c=c;
	            this->x=x;
	            this->y=y;
				//cout << "cercle"
				this->type=4;
				this->a=d;
			}  
			else{
				this->type=0;
				//cout << "NOTcercle";		
			}  
		}
		
		void set_croix(int x, int y,int a,int b,int c){
			if(a>0 && b>0){
				this->c=c;
	            this->x=x;
	            this->y=y;
				this->type=6;
				this->a=a;
				this->b=b;	
			}  
			else  this->type=0;
		}
		
		void set_rectangle(int x, int y,int a,int b,int c){
		//	cout << a << b << endl;
			if(a>0 && b>0){
				this->c=c;
	            this->x=x;
	            this->y=y;
				this->a=a;
				this->b=b;	
				this->type=5;
			}
			else{
			  this->type=0;
			}
			
		}
		void set_triangle(int x, int y,int a,int b,int c){
			if(a>0 && b>0) {
				this->c=c;
	            this->x=x;
	            this->y=y;
	            this->a=a;
	            this->b=b;
	            
	            this->type=7;
			} 
			else  this->type=0;
		}
		int get_type(){
			return this->type;
		}
		
		
		int get_couleur(){
			return this->c;
		}
		int get_x_centre(){
			return this->x;
		}
		int get_y_centre(){
			return this->y;
		}
		int get_x_min(){
			if(this->type==2) return this->x;
			else return this->x-(this->a)/2;
		}
		int get_x_max(){
			if(this->type==2) return this->x;
			else return this->x+(this->a)/2;
		}
		int get_y_min(){
			if(this->type==1) return this->y;
			else if(this->type==7)return this->y-2*(this->b)/3;
			else if(this->type==4) return this->y-(this->a)/2;
			else return this->y-(this->b)/2;
		}
		int get_y_max(){
			if(this->type==1) return this->y;
			else if(this->type==7)return this->y+(this->b)/3;
			else if(this->type==4) return this->y+(this->a)/2;
			else return this->y+(this->b)/2;
		}
		
		void dessiner(){
			setcolor(this->c);
			switch(this->type){
			case 1: 
				line(this->get_x_min(),this->get_y_min(),this->get_x_max(),this->get_y_max());
				break;
			case 2: 
				line(this->get_x_min(),this->get_y_min(),this->get_x_max(),this->get_y_max());
				break;
			case 3: 
				line(this->get_x_min(),this->get_y_min(),this->get_x_max(),this->get_y_max());
				break;
			case 4 : 
				circle(this->x,this->y,this->a/2);
				break;
			case 5 :
			    rectangle(this->get_x_min(),this->get_y_min(),this->get_x_max(),this->get_y_max());
				break;
			case 6 :
				line(this->get_x_min(),this->get_y_min(),this->get_x_max(),this->get_y_max());
				line(this->get_x_min(),this->get_y_max(),this->get_x_max(),this->get_y_min());
				break;
			case 7 :
				line(this->get_x_min(),this->get_y_max(),this->x,this->get_y_min());
				line(this->x,this->get_y_min(),this->get_x_max(),this->get_y_max());
				line(this->get_x_min(),this->get_y_max(),this->get_x_max(),this->get_y_max());
				break;
			}
			
		}
		
		void deplacer(int dx,int dy,fenetres f){
			int cinit=this->c;
			this->c=f.get_couleur_fond();
			this->dessiner();
			this->x+=dx;
			this->y+=dy;
			this->c=cinit;
			this->dessiner();
			
		}
	
	
	
};

#endif
