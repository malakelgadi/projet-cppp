#include <iostream>
#include <graphics.h>
#include <cmath>
#include "fenetres.h"
#include "figure.h"
#include "dessin.h"
using namespace std;

int main(int argc, char** argv) {
	fenetres f;
	int x,y;
	f.ouvrir_graphique();
	x=f.get_x_max()/2;
	y=f.get_y_max()/2;
	f.allume(x,y,f.get_couleur_fond()+4);
	delay(3000);//pour faire pause a l execution du programme
	//f.fermer_graphique();
	
	cout << "start";
	
	figure t;
	t.set_cercle(x,60,40,14);
	t.dessiner();
	delay(500);	
	
	figure c;
	c.set_rectangle(x,120,40,80,14);
	c.dessiner();
	delay(500);	
	
	figure bd;
	bd.set_droite(c.get_x_min()-30,c.get_y_min()+30,60,-30,14);
	bd.dessiner();
	
	figure bg;
	bg.set_droite(c.get_x_max()+30,c.get_y_min()+30,60,30,14);
	bg.dessiner();
	
	figure jd;
	jd.set_droite(c.get_x_min()+10,c.get_y_max()+30,0,60,14);
	jd.dessiner();
	
	figure jg;
	jg.set_droite(c.get_x_max()-10,c.get_y_max()+30,0,60,14);
	jg.dessiner();

	dessin bonhomme;
	//figure tb[6] = {t,c,bd,bg,jg,jd};
	bonhomme.tab[0]=bd;
	bonhomme.tab[1]=c;
	bonhomme.tab[2]=t;
	bonhomme.tab[3]=bg;
	bonhomme.tab[4]=jd;
	bonhomme.tab[5]=jg;
	delay(1000);
//	cout << "//_2222___";
		delay(1000);
	/*bonhomme.ajouterFigure(t);
	bonhomme.ajouterFigure(c);
	bonhomme.ajouterFigure(bd);
	bonhomme.ajouterFigure(bg);
	bonhomme.ajouterFigure(jd);
	bonhomme.ajouterFigure(jg);*/
	

//	cout << "//____" << bonhomme.nbF << endl;
	bonhomme.deplacerD(250,220,f);
	//cout << "//_333___";
		
		
	double X, Y, ang;
    double r = y-125;
    const double pi = acos(-1.0);
    cout << y;
    cout << X;
    X = r;
    cout << X;
    for (int i = 0; i<360; i++){
        int xx=X,yy=Y;
        ang = i * pi/180.0;//permet de convertir un angle en degr�s (i) en radians (ang)
        X = int(r * sin(ang));
        Y= int(r * cos(ang));
        bonhomme.deplacerD(X-xx,Y-yy,f);
        delay(25);
    }
	
	delay(5000);
	
	       
	
	
	return 0;
	
}
