#include <iostream>
#include "test.h"

using namespace std;

void fonction() {
    test premier(1);
}

void fonction2() {
    test second(2);
}

int main() {
    fonction();
    fonction2();

    return 0;
}

