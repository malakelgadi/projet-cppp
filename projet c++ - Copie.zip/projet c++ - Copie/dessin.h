#include "figure.h"

#ifndef DESSIN_H
#define DESSIN_H

class dessin
{
	public:
		figure tab [100];
		int nbF;
		
		dessin(){
			this->nbF=25;
		}
		

		void deplacerD(int dx, int dy, fenetres f){
 			for(int i=0;i<this->nbF;i++) 
				this->tab[i].deplacer(dx,dy,f);
					
		}
		
};

#endif

