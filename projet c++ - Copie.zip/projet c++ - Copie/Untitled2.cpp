#include<iostream>
using namespace std:
#include "test.h"
void fonction1();
void fonction2();
test premier (1);
 int main(){
 	test second(2);
	  fonction();
	  fonction2();
 return 0;
 }

