#ifndef TEST_H
#define TEST_H

#include <iostream>
using namespace std;

class test {
public:
    test(int inNumero) : Numero(inNumero) {
        cout << "Constructeur de l'objet numero " << Numero << endl;
    }

    ~test() {
        cout << "Destructeur de l'objet numero " << Numero << endl;
    }

private:
    int Numero;
};

#endif

